export default {
//   "headingLevel": 3,
  "messages": [
      {
          "date": "2023-08-23T02:30:00+04:30",
          "policyNumber": "1111AAAA",
          "read": false,
          "requestId": "11111111-8C94-6E4C-9FE1-6E6E2800AF88",
          "subject": "Lorem ipsum dolor sit amet, consectetur adipiscing elit"
      },
      {
          "date": "2023-09-09T09:00:00+04:00",
          "policyNumber": "2222BBBB",
          "read": true,
          "requestId": "22222222-8C94-6E4C-9FE1-6E6E2800AF88",
          "subject": "Lorem ipsum dolor sit amet, consectetur adipiscing elit"
      },
      {
          "date": "2023-10-10T10:00:00+04:00",
          "policyNumber": "3333CCCC",
          "read": false,
          "requestId": "33333333-8C94-6E4C-9FE1-6E6E2800AF88",
          "subject": "Lorem ipsum dolor sit amet, consectetur adipiscing elit"
      },
      {
          "date": "2023-11-11T11:00:00+04:00",
          "policyNumber": "4444DDDD",
          "read": true,
          "requestId": "44444444-8C94-6E4C-9FE1-6E6E2800AF88",
          "subject": "Lorem ipsum dolor sit amet, consectetur adipiscing elit"
      },
      {
          "date": "2023-12-12T12:00:00+04:00",
          "policyNumber": "5555EEEE",
          "read": true,
          "requestId": "55555555-8C94-6E4C-9FE1-6E6E2800AF88",
          "subject": "Lorem ipsum dolor sit amet, consectetur adipiscing elit"
      }
  ]
}